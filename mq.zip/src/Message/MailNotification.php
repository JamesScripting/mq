<?php

namespace App\Message;

class MailNotification
{
    private $description;
    private $id;
    private $from;

    public function __construct(string $description, int $id, string $from)
    {
        $this->description = $description;
        $this->id = $id;
        $this->from = $from;
    }

    

    /**
     * Get the value of description
     */ 
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * Get the value of id
     */ 
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Get the value of from
     */ 
    public function getFrom(): string
    {
        return $this->from;
    }
}